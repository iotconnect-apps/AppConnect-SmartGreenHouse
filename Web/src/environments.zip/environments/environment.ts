export const environment = {
	production: true,
	baseUrl: "http://192.168.3.185:3722/api/",
};
