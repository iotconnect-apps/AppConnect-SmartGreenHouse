export const environment = {
	production: true,
	baseUrl: "https://192.168.3.185:3723/api/",
};